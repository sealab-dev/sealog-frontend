import { FILE_DOMAIN } from "@/constants/domain";
import { DEFAULT_THUMBNAIL } from "@/constants/images";
import { WaveDivider } from "@/components/ui/wave/WaveDivider";
import styles from "./PostThumbnail.module.css";

interface PostThumbnailProps {
  thumbnailPath?: string | null;
  title: string;
}

export const PostThumbnail = ({ thumbnailPath, title }: PostThumbnailProps) => {
  const displayImageUrl = thumbnailPath
    ? FILE_DOMAIN + thumbnailPath
    : DEFAULT_THUMBNAIL;

  return (
    <section className={styles.banner}>
      <div className={styles.backgroundContainer}>
        <img
          src={displayImageUrl}
          alt={title}
          className={styles.thumbnailImage}
        />
        <div className={styles.bannerOverlay} />

        {/* 공통 물결 컴포넌트 */}
        <WaveDivider
          fillColor="var(--global-bg-primary)"
          height={100}
          id="wave-post-thumbnail"
        />
      </div>
    </section>
  );
};
