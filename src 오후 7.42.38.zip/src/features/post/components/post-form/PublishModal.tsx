import { useState } from "react";
import { X, Plus, BookOpen } from "lucide-react";
import styles from "./PublishModal.module.css";

/* ------------------------------------------------------------------ */
/* Types                                                                */
/* ------------------------------------------------------------------ */
export interface SeriesOption {
  id: number;
  name: string;
}

interface PublishModalProps {
  isOpen: boolean;
  seriesList: SeriesOption[];
  onConfirm: (seriesId: number | null, newSeriesName: string | null) => void;
  onCancel: () => void;
}

type SeriesMode = "existing" | "new";

/* ------------------------------------------------------------------ */
/* Component                                                            */
/* ------------------------------------------------------------------ */
export const PublishModal = ({
  isOpen,
  seriesList,
  onConfirm,
  onCancel,
}: PublishModalProps) => {
  // 기존 시리즈가 있으면 existing 먼저, 없으면 new 먼저
  const [mode, setMode] = useState<SeriesMode>(
    seriesList.length > 0 ? "existing" : "new",
  );
  const [selectedSeriesId, setSelectedSeriesId] = useState<number | null>(
    seriesList.length > 0 ? seriesList[0].id : null,
  );
  const [newSeriesName, setNewSeriesName] = useState("");
  const [newSeriesError, setNewSeriesError] = useState("");

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (mode === "new") {
      const trimmed = newSeriesName.trim();
      if (!trimmed) {
        setNewSeriesError("시리즈 이름을 입력해주세요");
        return;
      }
      if (trimmed.length > 50) {
        setNewSeriesError("50자 이하로 입력해주세요");
        return;
      }
      onConfirm(null, trimmed);
    } else {
      if (!selectedSeriesId) {
        return; // 선택 안 된 경우 — UI에서 막힘
      }
      onConfirm(selectedSeriesId, null);
    }
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onCancel();
  };

  return (
    <div className={styles.overlay} onClick={handleOverlayClick}>
      <div className={styles.modal} role="dialog" aria-modal="true">
        {/* 헤더 */}
        <div className={styles.header}>
          <h2 className={styles.title}>글 발행</h2>
          <button
            type="button"
            className={styles.closeButton}
            onClick={onCancel}
          >
            <X size={20} />
          </button>
        </div>

        {/* 본문 */}
        <div className={styles.body}>
          <p className={styles.question}>이 글을 포함할 시리즈를 선택하세요</p>

          {/* 탭 */}
          <div className={styles.tabs}>
            {seriesList.length > 0 && (
              <button
                type="button"
                className={`${styles.tab} ${mode === "existing" ? styles.tabActive : ""}`}
                onClick={() => setMode("existing")}
              >
                <BookOpen size={15} />
                기존 시리즈
              </button>
            )}
            <button
              type="button"
              className={`${styles.tab} ${mode === "new" ? styles.tabActive : ""}`}
              onClick={() => setMode("new")}
            >
              <Plus size={15} />새 시리즈
            </button>
          </div>

          {/* 기존 시리즈 목록 */}
          {mode === "existing" && (
            <ul className={styles.seriesList}>
              {seriesList.map((s) => (
                <li key={s.id}>
                  <label
                    className={`${styles.seriesItem} ${selectedSeriesId === s.id ? styles.seriesItemActive : ""}`}
                  >
                    <input
                      type="radio"
                      name="seriesId"
                      className={styles.radioInput}
                      checked={selectedSeriesId === s.id}
                      onChange={() => setSelectedSeriesId(s.id)}
                    />
                    <span className={styles.seriesName}>{s.name}</span>
                  </label>
                </li>
              ))}
            </ul>
          )}

          {/* 새 시리즈 입력 */}
          {mode === "new" && (
            <div className={styles.newSeriesWrapper}>
              <input
                type="text"
                className={`${styles.newSeriesInput} ${newSeriesError ? styles.inputError : ""}`}
                placeholder="시리즈 이름을 입력하세요"
                value={newSeriesName}
                onChange={(e) => {
                  setNewSeriesName(e.target.value);
                  if (newSeriesError) setNewSeriesError("");
                }}
                maxLength={50}
                autoFocus
              />
              <div className={styles.inputMeta}>
                {newSeriesError ? (
                  <span className={styles.errorText}>{newSeriesError}</span>
                ) : (
                  <span />
                )}
                <span className={styles.charCount}>
                  {newSeriesName.length}/50
                </span>
              </div>
            </div>
          )}
        </div>

        {/* 푸터 */}
        <div className={styles.footer}>
          <button
            type="button"
            className={styles.cancelButton}
            onClick={onCancel}
          >
            취소
          </button>
          <button
            type="button"
            className={styles.confirmButton}
            onClick={handleConfirm}
            disabled={mode === "existing" && !selectedSeriesId}
          >
            발행하기
          </button>
        </div>
      </div>
    </div>
  );
};
