import { useState, useEffect } from "react";
import { Outlet } from "react-router-dom";
import { AppHeader } from "../shared/_components/AppHeader";
import { AppFooter } from "../shared/_components/AppFooter";
import { ProfileCard } from "./_components/ProfileCard";
import { SearchBar } from "./_components/SearchBar";
import { StackList } from "./_components/StackList";
import styles from "./PostsLayout.module.css";
import stylesHeader from "../shared/_components/AppHeader.module.css";
import { PanelLeft } from "lucide-react";

interface AppHeaderProps {
  onSidebarToggle?: () => void;
}

export const PostsLayout = ({ onSidebarToggle }: AppHeaderProps) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleToggleSidebar = () => setIsSidebarOpen((prev) => !prev);
  const handleCloseSidebar = () => setIsSidebarOpen(false);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isSidebarOpen) handleCloseSidebar();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isSidebarOpen]);

  useEffect(() => {
    if (isSidebarOpen && window.innerWidth < 1024) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isSidebarOpen]);

  return (
    <div className={styles.layout}>
      {/* 사이드바 */}
      <aside className={`${styles.aside} ${isSidebarOpen ? styles.open : ""}`}>
        <div className={styles.sidebar}>
          <ProfileCard onNavigate={handleCloseSidebar} />
          <SearchBar onSearch={handleCloseSidebar} />
          <StackList onStackSelect={handleCloseSidebar} />
        </div>
      </aside>
      <button
        className={`${styles.sidebarToggle} ${
          isSidebarOpen ? styles.toggleOpen : ""
        }`}
        onClick={handleToggleSidebar}
        aria-label="사이드바 열기/닫기"
      >
        <PanelLeft className={styles.sidebarIcon} />
      </button>

      <div className={styles.mainContainer}>
        <AppHeader />
        <main className={styles.main}>
          <Outlet />
        </main>
        <footer className={styles.footer}>
          <AppFooter />
        </footer>
      </div>

      {isSidebarOpen && (
        <div className={styles.overlay} onClick={handleCloseSidebar} />
      )}
    </div>
  );
};
