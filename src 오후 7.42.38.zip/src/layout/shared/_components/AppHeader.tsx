import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { HiOutlineLogin } from "react-icons/hi";
import { PanelLeft } from "lucide-react";
import { Anchor } from "lucide-react";
import { GoLinkExternal } from "react-icons/go";
import { useAuthStore } from "@/features/auth/stores/authStore";
import { useLoginModalStore } from "@/features/auth/stores/loginModalStore";
import { ProfileDropdown } from "./ProfileDropdown";
import styles from "./AppHeader.module.css";

export const AppHeader = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  const { user, isAuthenticated } = useAuthStore();
  const { openLoginModal } = useLoginModalStore();

  // // 현재 페이지가 유저 페이지인지 판단
  // const isUserPage = location.pathname.startsWith("/user/");

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header>
      <div className={styles.container}>
        <div
          className={`${styles.content} ${isScrolled ? styles.scrolled : ""}`}
        >
          <div className={styles.headerBg} />

          <div className={styles.leftSection}>
            <button
              className={styles.logoWrapper}
              onClick={() => navigate("/")}
              aria-label="홈으로"
            >
              <Anchor className={styles.shellIcon} />
            </button>

            <nav className={styles.nav}>
              {user && (
                <button
                  onClick={() => navigate(`/user/${user.nickname}/write`)}
                  className={styles.navButton}
                >
                  Post
                </button>
              )}
              {/* <button
              onClick={() => navigate("/members")}
              className={styles.navButton}
            >
              SeaLab <GoLinkExternal />
            </button> */}
            </nav>
          </div>

          {/* 오른쪽: 프로필/로그인 */}
          <div className={styles.rightSection}>
            {isAuthenticated ? (
              <ProfileDropdown />
            ) : (
              <button onClick={openLoginModal} className={styles.authButton}>
                <HiOutlineLogin className={styles.authIcon} />
                <span>로그인</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
